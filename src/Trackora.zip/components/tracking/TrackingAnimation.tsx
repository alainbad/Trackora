import { useEffect, useState } from 'react'

interface Props {
  trackingNumber: string
  apiReady: boolean
  onComplete: () => void
}

const SCAN_STEPS = [
  { label: 'Parsing tracking number format…',     pct: 18  },
  { label: 'Querying 1,200+ carrier databases…',  pct: 40  },
  { label: 'Carrier matched — connecting…',        pct: 58  },
  { label: 'Retrieving live events from carrier…', pct: 72, hold: true },
  { label: 'Calculating AI delivery prediction…',  pct: 88  },
  { label: 'Building route intelligence…',         pct: 96  },
  { label: 'Ready',                                pct: 100 },
]

const HOLD_STEP = SCAN_STEPS.findIndex(s => s.hold)

export default function TrackingAnimation({ trackingNumber, apiReady, onComplete }: Props) {
  const [step,      setStep]      = useState(0)
  const [charIndex, setCharIndex] = useState(0)
  const [done,      setDone]      = useState(false)

  useEffect(() => {
    if (charIndex < trackingNumber.length) {
      const t = setTimeout(() => setCharIndex(i => i + 1), 40)
      return () => clearTimeout(t)
    }
  }, [charIndex, trackingNumber.length])

  useEffect(() => {
    if (step >= SCAN_STEPS.length - 1) {
      const t = setTimeout(() => { setDone(true); onComplete() }, 400)
      return () => clearTimeout(t)
    }
    if (step === HOLD_STEP && !apiReady) return
    const delay = step === 0 ? 300 : step === 1 ? 500 : step === 2 ? 400 : 320
    const t = setTimeout(() => setStep(s => s + 1), delay)
    return () => clearTimeout(t)
  }, [step, apiReady, onComplete])

  useEffect(() => {
    if (apiReady && step === HOLD_STEP) {
      const t = setTimeout(() => setStep(s => s + 1), 300)
      return () => clearTimeout(t)
    }
  }, [apiReady, step])

  if (done) return null

  const currentStep = SCAN_STEPS[step]
  const pct         = currentStep.pct
  const isHolding   = step === HOLD_STEP && !apiReady

  // Theme colours
  const accent  = isHolding ? '#f59e0b' : '#6366f1'
  const accent2 = isHolding ? '#fbbf24' : '#22d3ee'
  const accent3 = isHolding ? '#f59e0b' : '#a78bfa'
  const ringA   = isHolding ? 'rgba(245,158,11,0.45)' : 'rgba(99,102,241,0.45)'
  const ringB   = isHolding ? 'rgba(245,158,11,0.3)'  : 'rgba(34,211,238,0.35)'
  const ringC   = isHolding ? 'rgba(245,158,11,0.25)' : 'rgba(167,139,250,0.3)'

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', minHeight: '420px', gap: '32px', padding: '40px 24px',
    }}>

      {/* ── Rotating Earth + orbital rings ── */}
      <div style={{ position: 'relative', width: '180px', height: '180px', flexShrink: 0 }}>
        <style>{`
          @keyframes land-drift {
            from { transform: translateX(0px); }
            to   { transform: translateX(-96px); }
          }
          @keyframes orb1  { to { transform: rotate(360deg);  } }
          @keyframes orb2  { to { transform: rotate(-360deg); } }
          @keyframes orb3  { to { transform: rotate(360deg);  } }
          @keyframes pulse-glow {
            0%,100% { opacity:0.6; }
            50%     { opacity:1;   }
          }
          @keyframes scan-beam {
            0%   { left: -100%; }
            100% { left:  200%; }
          }
          @keyframes blink {
            0%,100% { opacity:1; }
            50%     { opacity:0; }
          }
          @keyframes shimmer {
            0%   { background-position: -200% center; }
            100% { background-position:  200% center; }
          }
        `}</style>

        <svg width="180" height="180" viewBox="0 0 180 180" overflow="visible">
          <defs>
            {/* Ocean gradient */}
            <radialGradient id="ocean" cx="38%" cy="32%" r="70%">
              <stop offset="0%"   stopColor="#1e3a5f" />
              <stop offset="60%"  stopColor="#0c1a3a" />
              <stop offset="100%" stopColor="#060d1f" />
            </radialGradient>
            {/* Atmosphere rim */}
            <radialGradient id="atmo" cx="50%" cy="50%" r="50%">
              <stop offset="74%" stopColor="transparent" />
              <stop offset="100%" stopColor={isHolding ? 'rgba(245,158,11,0.28)' : 'rgba(99,102,241,0.32)'} />
            </radialGradient>
            {/* Specular highlight */}
            <radialGradient id="spec" cx="34%" cy="29%" r="45%">
              <stop offset="0%"   stopColor="rgba(255,255,255,0.18)" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
            {/* Land colour */}
            <clipPath id="globe-clip">
              <circle cx="90" cy="90" r="52" />
            </clipPath>
          </defs>

          {/* ── Back halves of orbital rings (behind globe) ── */}
          {/* Ring A back — flat, slow */}
          <g style={{ transformOrigin:'90px 90px', animation:`orb1 5s linear infinite` }}>
            <path d="M 90,90 m -74,0 a 74,22 0 0 0 148,0" fill="none"
              stroke={ringA} strokeWidth="1.4" strokeDasharray="5,4" opacity="0.6"/>
          </g>
          {/* Ring B back — tilted, medium */}
          <g style={{ transformOrigin:'90px 90px', transform:'rotate(-55deg)', animation:`orb2 7s linear infinite` }}>
            <path d="M 90,90 m -68,0 a 68,20 0 0 0 136,0" fill="none"
              stroke={ringB} strokeWidth="1.2" strokeDasharray="3,5" opacity="0.5"/>
          </g>
          {/* Ring C back — steep, fast */}
          <g style={{ transformOrigin:'90px 90px', transform:'rotate(40deg)', animation:`orb3 3.5s linear infinite` }}>
            <path d="M 90,90 m -60,0 a 60,16 0 0 0 120,0" fill="none"
              stroke={ringC} strokeWidth="1" strokeDasharray="4,3" opacity="0.45"/>
          </g>

          {/* ── Globe body ── */}
          <circle cx="90" cy="90" r="52" fill="url(#ocean)" />

          {/* Grid + continents (clipped) */}
          <g clipPath="url(#globe-clip)">

            {/* Latitude lines */}
            {[
              { cy: 52, rx: 52, ry: 9  },
              { cy: 63, rx: 52, ry: 17 },
              { cy: 75, rx: 52, ry: 23 },
              { cy: 90, rx: 52, ry: 26 },
              { cy:105, rx: 52, ry: 23 },
              { cy:117, rx: 52, ry: 17 },
              { cy:128, rx: 52, ry: 9  },
            ].map((l, i) => (
              <ellipse key={i} cx="90" cy={l.cy} rx={l.rx} ry={l.ry}
                fill="none" stroke="rgba(148,163,184,0.1)" strokeWidth="0.7" />
            ))}

            {/* Longitude curves */}
            {[
              { rx: 2,  ry: 52 },
              { rx: 26, ry: 52 },
              { rx: 46, ry: 52 },
            ].map((m, i) => (
              <ellipse key={i} cx="90" cy="90" rx={m.rx} ry={m.ry}
                fill="none" stroke="rgba(148,163,184,0.1)" strokeWidth="0.7" />
            ))}

            {/* Animated land masses — scroll horizontally to simulate rotation */}
            <g style={{ animation: 'land-drift 12s linear infinite' }}>
              {/* ── Continent set 1 ── */}
              {/* Europe/N-Africa */}
              <path d="M100,62 Q112,60 116,72 Q118,84 110,86 Q100,88 96,78 Q92,68 100,62Z"
                fill="rgba(16,185,129,0.55)" />
              {/* Sub-Saharan Africa */}
              <path d="M102,88 Q110,86 112,100 Q112,114 104,118 Q96,118 94,106 Q92,94 102,88Z"
                fill="rgba(16,185,129,0.5)" />
              {/* Americas */}
              <path d="M70,58 Q80,54 84,68 Q86,82 80,88 Q72,90 68,78 Q64,66 70,58Z"
                fill="rgba(16,185,129,0.45)" />
              <path d="M72,92 Q78,90 80,102 Q80,114 74,116 Q68,116 66,106 Q64,94 72,92Z"
                fill="rgba(16,185,129,0.42)" />
              {/* Asia */}
              <path d="M124,58 Q140,56 146,70 Q148,84 138,88 Q126,90 120,78 Q116,66 124,58Z"
                fill="rgba(16,185,129,0.52)" />
              {/* Australia */}
              <path d="M136,98 Q144,96 146,106 Q144,116 136,116 Q128,114 128,104 Q128,96 136,98Z"
                fill="rgba(16,185,129,0.45)" />

              {/* ── Continent set 2 (shifted right for seamless loop) ── */}
              <path d="M196,62 Q208,60 212,72 Q214,84 206,86 Q196,88 192,78 Q188,68 196,62Z"
                fill="rgba(16,185,129,0.55)" />
              <path d="M198,88 Q206,86 208,100 Q208,114 200,118 Q192,118 190,106 Q188,94 198,88Z"
                fill="rgba(16,185,129,0.5)" />
              <path d="M166,58 Q176,54 180,68 Q182,82 176,88 Q168,90 164,78 Q160,66 166,58Z"
                fill="rgba(16,185,129,0.45)" />
              <path d="M168,92 Q174,90 176,102 Q176,114 170,116 Q164,116 162,106 Q160,94 168,92Z"
                fill="rgba(16,185,129,0.42)" />
              <path d="M220,58 Q236,56 242,70 Q244,84 234,88 Q222,90 216,78 Q212,66 220,58Z"
                fill="rgba(16,185,129,0.52)" />
              <path d="M232,98 Q240,96 242,106 Q240,116 232,116 Q224,114 224,104 Q224,96 232,98Z"
                fill="rgba(16,185,129,0.45)" />
            </g>
          </g>

          {/* Atmosphere + specular */}
          <circle cx="90" cy="90" r="52" fill="url(#atmo)" />
          <circle cx="90" cy="90" r="52" fill="url(#spec)" />
          <circle cx="90" cy="90" r="52" fill="none"
            stroke={accent} strokeWidth="1.5" opacity="0.6"
            style={{ animation: 'pulse-glow 2s ease-in-out infinite' }} />

          {/* ── Front halves of orbital rings + dots (in front of globe) ── */}
          {/* Ring A front */}
          <g style={{ transformOrigin:'90px 90px', animation:`orb1 5s linear infinite` }}>
            <path d="M 90,90 m -74,0 a 74,22 0 0 1 148,0" fill="none"
              stroke={ringA} strokeWidth="1.8" strokeDasharray="5,4"/>
            {/* Satellite dot */}
            <circle cx="164" cy="90" r="4.5" fill={accent}
              style={{ filter: `drop-shadow(0 0 6px ${accent})` }} />
          </g>
          {/* Ring B front */}
          <g style={{ transformOrigin:'90px 90px', transform:'rotate(-55deg)', animation:`orb2 7s linear infinite` }}>
            <path d="M 90,90 m -68,0 a 68,20 0 0 1 136,0" fill="none"
              stroke={ringB} strokeWidth="1.5" strokeDasharray="3,5"/>
            <circle cx="158" cy="90" r="3.5" fill={accent2}
              style={{ filter: `drop-shadow(0 0 5px ${accent2})` }} />
          </g>
          {/* Ring C front */}
          <g style={{ transformOrigin:'90px 90px', transform:'rotate(40deg)', animation:`orb3 3.5s linear infinite` }}>
            <path d="M 90,90 m -60,0 a 60,16 0 0 1 120,0" fill="none"
              stroke={ringC} strokeWidth="1.2" strokeDasharray="4,3"/>
            <circle cx="150" cy="90" r="3" fill={accent3}
              style={{ filter: `drop-shadow(0 0 4px ${accent3})` }} />
          </g>
        </svg>
      </div>

      {/* ── Tracking number scan ── */}
      <div style={{
        padding: '14px 24px', borderRadius: '12px',
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${isHolding ? 'rgba(245,158,11,0.3)' : 'rgba(99,102,241,0.25)'}`,
        position: 'relative', overflow: 'hidden',
        maxWidth: '400px', width: '100%',
        transition: 'border-color 0.4s ease',
      }}>
        <div style={{
          position: 'absolute', top: 0, bottom: 0, width: '60px',
          background: `linear-gradient(90deg, transparent, ${isHolding ? 'rgba(245,158,11,0.2)' : 'rgba(99,102,241,0.3)'}, transparent)`,
          animation: 'scan-beam 1.8s ease-in-out infinite',
          pointerEvents: 'none',
        }} />
        <div style={{ fontFamily: 'monospace', fontSize: '16px', letterSpacing: '2px', textAlign: 'center' }}>
          {trackingNumber.split('').map((ch, i) => (
            <span key={i} style={{
              color: i < charIndex
                ? (isHolding ? '#f59e0b' : '#818cf8')
                : 'rgba(248,250,252,0.15)',
              transition: 'color 0.1s',
              textShadow: i < charIndex
                ? `0 0 8px ${isHolding ? 'rgba(245,158,11,0.6)' : 'rgba(99,102,241,0.8)'}`
                : 'none',
            }}>{ch}</span>
          ))}
          <span style={{ animation: 'blink 0.8s step-end infinite', color: isHolding ? '#f59e0b' : '#818cf8' }}>|</span>
        </div>
      </div>

      {/* ── Progress bar ── */}
      <div style={{ width: '100%', maxWidth: '400px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
          <span style={{ fontSize: '13px', color: isHolding ? '#f59e0b' : 'rgba(248,250,252,0.6)', transition: 'color 0.3s' }}>
            {isHolding ? 'Waiting for carrier response…' : currentStep.label}
          </span>
          <span style={{ fontSize: '13px', color: isHolding ? '#f59e0b' : '#818cf8', fontWeight: 700, transition: 'color 0.3s' }}>
            {isHolding ? '…' : `${pct}%`}
          </span>
        </div>
        <div style={{ height: '4px', borderRadius: '2px', background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
          {isHolding ? (
            <div style={{
              height: '100%', borderRadius: '2px', width: '40%',
              background: 'linear-gradient(90deg, transparent, #f59e0b, transparent)',
              backgroundSize: '200% 100%',
              animation: 'shimmer 1.4s ease-in-out infinite',
            }} />
          ) : (
            <div style={{
              height: '100%', borderRadius: '2px',
              background: 'linear-gradient(90deg, #6366f1, #22d3ee)',
              width: `${pct}%`,
              transition: 'width 0.4s cubic-bezier(0.4,0,0.2,1)',
              boxShadow: '0 0 8px rgba(99,102,241,0.6)',
            }} />
          )}
        </div>
      </div>

      {/* ── Step dots ── */}
      <div style={{ display: 'flex', gap: '8px' }}>
        {SCAN_STEPS.slice(0, -1).map((_, i) => (
          <div key={i} style={{
            width: i <= step ? '20px' : '6px', height: '6px', borderRadius: '3px',
            background: i <= step
              ? (isHolding && i === HOLD_STEP ? '#f59e0b' : '#6366f1')
              : 'rgba(255,255,255,0.12)',
            transition: 'all 0.3s',
          }} />
        ))}
      </div>
    </div>
  )
}
